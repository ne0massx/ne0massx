<?php
namespace app\forms;

use std, gui, framework, app;


class AlreadyKey extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $this->button->enabled = false;
        $this->timer->enabled = true;
        $text = $this->edit->text;
        $this->label4->text = $text;
        if ($text == UB34S632SDK3) {
            $text2 = $this->editAlt->text;
            $this->label6->text = $text2;
            $text4 = $this->edit4->text;
            $this->label8->text = $text4;
        }
        else {
            $text3 = $this->edit3->text;
            $this->label6->text = $text3;
            $text5 = $this->edit5->text;
            $this->label8->text = $text5;
        }
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }


}
